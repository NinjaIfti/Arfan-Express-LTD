import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import vue from '@vitejs/plugin-vue';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
    plugins: [
        laravel(['resources/css/app.css', 'resources/js/app.js']),
        vue({
            template: {
                compilerOptions: {
                    // Optimize Vue compilation
                    hoistStatic: true,
                    cacheHandlers: true,
                }
            }
        }),
        tailwindcss(), // Add Tailwind v4 Vite plugin
    ],
    resolve: {
        alias: {
            '@': '/resources/js',
        },
    },
    build: {
        // Optimize build output
        rollupOptions: {
            output: {
                manualChunks: {
                    // Split vendor chunks for better caching
                    'vendor': ['vue', 'vue-router', 'pinia'],
                    'animations': ['gsap'],
                    'utils': ['aos']
                }
            }
        },
        // Remove terser minification for now to avoid dependency issues
        minify: 'esbuild',
        assetsInlineLimit: 0, // Don't inline any assets, keep them as separate files
    },
    // Handle public assets properly
    publicDir: 'public',
    // Optimize dev server
    server: {
        hmr: {
            overlay: false
        }
    }
});