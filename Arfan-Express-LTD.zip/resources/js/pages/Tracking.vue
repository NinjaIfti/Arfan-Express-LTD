<template>
  <div class="min-h-[60vh] flex flex-col items-center justify-center py-16">
    <h1 class="text-3xl font-bold mb-4 text-primary-700">Shipment Tracking</h1>
    <p class="text-gray-600 mb-8">This is a placeholder for the tracking page. You can add your tracking form or shipment status here.</p>
    <div class="bg-white rounded-xl shadow-lg p-8">
      <span class="text-gray-400">Tracking functionality coming soon...</span>
    </div>
  </div>
</template>

<script setup>
// Placeholder page
</script> 